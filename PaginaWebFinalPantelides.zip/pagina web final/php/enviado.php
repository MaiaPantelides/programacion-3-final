<?php

// Conectar con la base de datos
$mysqli = new mysqli ('localhost', 'root', '', 'nacionalidades');


$name = $_POST['name'];
$asunto = $_POST['asunto'];
$mensaje = $_POST['mensaje'];
$email = $_POST['correo'];

// ver lo que se está enviando, descomentar la siguiente sección

/*
echo "<pre>";
var_dump($_POST);
var_dump($_FILES);
echo "</pre>";
*/

// no sabemos para qué está esto
// header(header: "id:thank-you-message");

// Descomentar para enviar mail
// $destino =  "maia.pantelides@comunidad.ub.edu.ar";
// $contenido = "este mensaje fue enviado por " . $name . ", su correo es " . $email . "\r\n" . "asunto: " .$asunto . "enviado el " . date(format: 'd/m/Y', timestamp: time ());
// mail(to: $destino, subject: "contacto", message: $contenido);


echo 'mensaje enviado correctamente: la persona '. $name . ", su correo es " . $email . "\r\n" . "asunto: " .$asunto . "enviado el " . date(format: 'd/m/Y', timestamp: time ());;

// validación del email, 
// para simular mal envio de dirección de mail, descomentar la línea siguiente
// $email = "mal dirección de mail";

if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo "La dirección de email '$email' es válida.\n";
} else {
    echo "La dirección de email '$email' NO es válida.\n";
}

$nombre_archivo = $_FILES['userfile']['name'];
$tipo_archivo = $_FILES['userfile']['type'];
$tamano_archivo = $_FILES['userfile']['size'];
if( !( strpos ($tipo_archivo, "gif") || strpos ($tipo_archivo, "jpeg") ) ) {
   echo "<br><br>La  extensión del archivo no es correcta<br>Se permiten archivos .gif o .jpeg";
} else if($tamano_archivo > 100000) {
   echo "<br><br>Mal, sólo se permiten archivos de 100kb máximo";
} else if (move_uploaded_file ($_FILES['userfile'] ['tmp_name'], $nombre_archivo)){
   echo "<br><br>El archivo ha sido cargado correctamente.";
} else{
  echo "<br><br>Ocurrió algún error al subir el ficheron. No pudo guardarse.";
}


?>
