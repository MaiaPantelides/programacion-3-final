
<!DOCTYPE html>
<html>
<head>
  <title>Contacto</title>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="../css/estilo.css">
</head>
<body>
  <script src="../js/javascript.js"></script>

  <img src="../imagenes/logops.png" alt="Logo" class="logo">
  
  <button class="menu-toggle">☰</button>
  
  <ul class="horizontal">
    <li><a href="../index.html">Inicio</a></li>
    <li><a href="../dibujos/index.html">Dibujos</a></li>
    <li><a href="../animaciones/index.html">Animaciones</a></li>
    <li><a href="juego/index.html">Juegos</a></li>
    <li><a href="#">Contacto</a></li>
  </ul>

  <div class="contacto-contenedor">
    <form class="contacto-izq" method="post" action="../php/enviado.php" enctype="multipart/form-data" >
      <div class="contacto-izq-titulo">
        <h2>Contacto</h2>
        <p> 
          Mail: maia.pantelides@gmail.com<br>
          Teléfono: +54 11 1234-5678<br>
          Ubicación: Parque Chacabuco<br>
          Redes: <a href="https://www.instagram.com/maipanqueque" target="_blank" class="ig">@maipanqueque</a>
        </p>
        <hr>
      </div>

      <input type="text" id="name" name="name" placeholder="Nombre" class="contacto-inputs" value="persona" >
      <input type="email" id="correo" name="correo" placeholder="Correo electrónico" class="contacto-inputs" value="maia.pantelides@gmail.com">
      <input type="text" id="asunto" name="asunto" placeholder="Asunto" class="contacto-inputs" value="asunto">
      <textarea name="mensaje" placeholder="Mensaje" class="contacto-inputs" >Mensaje</textarea>
      <input type="file" name="userfile" placeholder="Subir archivo" class="archivo" >
<select class="contacto-inputs" >
  <option value="0">Seleccione:</option>
  <?php
  $mysqli = new mysqli("localhost", "root", "", "nacionalidades");

  if ($mysqli->connect_errno) {
      echo "Error al conectar a MySQL: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
  } else {
      $query = $mysqli->query("SELECT * FROM pais");

      while ($valores = $query->fetch_assoc()) {
          echo '<option value="' . $valores['id'] . '">' . $valores['pais'] . '</option>';
      }
  }
  ?>
</select>


      <button type="submit">Enviar</button>
    </form>
    
    <div class="contacto-dere">
      <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d26262.618504304693!2d-58.44905999869502!3d-34.633803970634496!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x95bccbb7065d907f%3A0x9ce77385d2f35dd3!2sParque%20Chacabuco!5e0!3m2!1ses!2sar!4v1746380256501!5m2!1ses!2sar"
       width="600" height="450" style="border:0;" allowfullscreen loading="lazy"></iframe>
    </div>
  </div>

  <div id="mari">
    <img src="../imagenes/mari.png" width="50" height="50">
  </div>
</body>
</html>
