document.addEventListener('DOMContentLoaded', function() {
  const mari = document.getElementById("mari");
  if (mari) {
    let mouseX = 0, mouseY = 0;
    let posX = 0, posY = 0;
    const smoothness = 0.2;
    
    function updateMariPosition() {
      posX += (mouseX - posX) * smoothness;
      posY += (mouseY - posY) * smoothness;
      mari.style.left = `${posX}px`;
      mari.style.top = `${posY}px`;
      requestAnimationFrame(updateMariPosition);
    }
    
    document.addEventListener('mousemove', (e) => {
      mouseX = e.clientX;
      mouseY = e.clientY;
    });
    
    updateMariPosition();
  }

const menuToggle = document.querySelector('.menu-toggle');
const mobileMenu = document.createElement('div');
mobileMenu.className = 'mobile-menu';

const navItems = document.querySelectorAll('ul.horizontal li a');
navItems.forEach(item => {
  const link = item.cloneNode(true);
  mobileMenu.appendChild(link);
});

document.body.appendChild(mobileMenu);

menuToggle.addEventListener('click', function(e) {
  mobileMenu.classList.toggle('show');
  this.innerHTML = mobileMenu.classList.contains('show') ? '✕' : '☰';
});

mobileMenu.addEventListener('click', function(e) {
  if (e.target.tagName === 'A') {
    mobileMenu.classList.remove('show');
    menuToggle.innerHTML = '☰';
  }
});


  const contactForm = document.querySelector('.contacto-izq form') || document.querySelector('form');
  if (contactForm) {
    contactForm.addEventListener('submit', function(e) {
      e.preventDefault();
      
      const name = document.getElementById('name')?.value;
      const email = document.getElementById('correo')?.value;
      const message = document.querySelector('textarea[name="mensaje"]')?.value;
      
      if (name && email && message) {
        contactForm.submit()
        return true;
        const thankYouMsg = document.createElement('div');
        thankYouMsg.id = "thank-you-message";
        thankYouMsg.style.cssText = `
          position: fixed;
          top: 50%;
          left: 50%;
          transform: translate(-50%, -50%);
          background: #f4e1e2;
          padding: 30px;
          border-radius: 15px;
          border: 3px dashed #c9184a;
          text-align: center;
          z-index: 1000;
          max-width: 80%;
          box-shadow: 0 5px 15px rgba(0,0,0,0.2);
          animation: fadeIn 0.5s ease;
          font-family: Arial, sans-serif;
        `;
        


        thankYouMsg.innerHTML = `
          <h2 style="color: #c9184a; margin-top:0;">¡Gracias por contactarme, ${name}!</h2>
          <p style="color: #590d22; font-size: 1.1em;">
            Te responderé a: <strong style="color: #a4133c;">${email}</strong>
          </p>
          <p style="color: #590d22; margin-top: 20px;">
            ¿Querés ver mis trabajos mientras tanto?<br>
            <a href="../animaciones/index.html">Ver animaciones</a> | 
            <a href="../dibujos/index.html">Ver dibujos</a>
          </p>
          <button style="
            background: linear-gradient(270deg, #c9184a, #590d22);
            color: white;
            border: none;
            padding: 10px 25px;
            border-radius: 50px;
            margin-top: 15px;
            cursor: pointer;
            font-weight: bold;
          " onclick="this.parentElement.remove()">¡Entendido!</button>
        `;
        
        document.body.appendChild(thankYouMsg);



      } else {
        const validarname = document.createElement('div');
        validarname.innerHTML = `
        <h2 style="color: #c9184a; margin-top:0;">Rellene el campo de nombre.</h2>
    
        <button style="
          background: linear-gradient(270deg, #c9184a, #590d22);
          color: white;
          border: none;
          padding: 10px 25px;
          border-radius: 50px;
          margin-top: 15px;
          cursor: pointer;
          font-weight: bold;
        " onclick="this.parentElement.remove()">¡Entendido!</button>
      `;
      
    
      validarname.style.cssText= `
          position: fixed;
          top: 50%;
          left: 50%;
          transform: translate(-50%, -50%);
          background: #f4e1e2;
          padding: 30px;
          border-radius: 15px;
          border: 3px dashed #c9184a;
          text-align: center;
          z-index: 1000;
          max-width: 80%;
          box-shadow: 0 5px 15px rgba(0,0,0,0.2);
          animation: fadeIn 0.5s ease;
          font-family: Arial, sans-serif;
        `;

        if (name == "") {
          document.body.appendChild(validarname);
          return false;
        }

        const validaremail = document.createElement('div');
        validaremail.innerHTML = `
        <h2 style="color: #c9184a; margin-top:0;">Rellene el campo de email.</h2>
    
        <button style="
          background: linear-gradient(270deg, #c9184a, #590d22);
          color: white;
          border: none;
          padding: 10px 25px;
          border-radius: 50px;
          margin-top: 15px;
          cursor: pointer;
          font-weight: bold;
        " onclick="this.parentElement.remove()">¡Entendido!</button>
      `;
      
    
      validaremail.style.cssText= `
          position: fixed;
          top: 50%;
          left: 50%;
          transform: translate(-50%, -50%);
          background: #f4e1e2;
          padding: 30px;
          border-radius: 15px;
          border: 3px dashed #c9184a;
          text-align: center;
          z-index: 1000;
          max-width: 80%;
          box-shadow: 0 5px 15px rgba(0,0,0,0.2);
          animation: fadeIn 0.5s ease;
          font-family: Arial, sans-serif;
        `;

        if (email == "") {
          document.body.appendChild(validaremail);
          return false;
        }       

        const validarmen = document.createElement('div');
        validarmen.innerHTML = `
        <h2 style="color: #c9184a; margin-top:0;">Rellene el campo de mensaje.</h2>
    
        <button style="
          background: linear-gradient(270deg, #c9184a, #590d22);
          color: white;
          border: none;
          padding: 10px 25px;
          border-radius: 50px;
          margin-top: 15px;
          cursor: pointer;
          font-weight: bold;
        " onclick="this.parentElement.remove()">¡Entendido!</button>
      `;
      
    
      validarmen.style.cssText= `
          position: fixed;
          top: 50%;
          left: 50%;
          transform: translate(-50%, -50%);
          background: #f4e1e2;
          padding: 30px;
          border-radius: 15px;
          border: 3px dashed #c9184a;
          text-align: center;
          z-index: 1000;
          max-width: 80%;
          box-shadow: 0 5px 15px rgba(0,0,0,0.2);
          animation: fadeIn 0.5s ease;
          font-family: Arial, sans-serif;
        `;

        
        if (message == "") {
          document.body.appendChild(validarmen);
          return false;
        }
      }
    });
  }
});
